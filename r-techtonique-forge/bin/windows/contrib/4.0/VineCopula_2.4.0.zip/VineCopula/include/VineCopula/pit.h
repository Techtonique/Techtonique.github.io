// Probability integral transform
void pit(int* n, int* d, int* family, int* type, double* par, double* nu, double* data, double* out);
void RvinePIT(int* T, int* d, int* family, int* maxmat, int* matrix, int* condirect, int* conindirect, double* par, double* par2, double* data, 
		 double* out, double* vv, double* vv2, int* calcupdate);
		 
