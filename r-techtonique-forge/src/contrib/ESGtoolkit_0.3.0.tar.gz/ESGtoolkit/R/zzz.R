#.onAttach <- function(lib, pkg) {
  #packageStartupMessage(
  #  ".\n")
#} 


.onLoad <- function(libname, pkgname) {
  
}
