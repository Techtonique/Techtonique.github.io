# version 0.3.0

- Use [VineCopula](http://tnagler.github.io/VineCopula/) package instead of CDVine (archived) for dependency simulation (means there's also now VineCopula's R-Vine Copulas simulation)
- Remove roxygen2 comments
- Create website with pkgdown, including docs --> https://techtonique.github.io/ESGtoolkit/


# version 0.2.0

- refactor files 
- add reproductibility seeds
- update vignette
- update LICENSE

# version 0.1.0

- Initial version