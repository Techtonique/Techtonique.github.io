library(testthat)
library(VineCopula)

test_check("VineCopula")
