library(testthat)
library(crossval)

test_check("crossval")
