# bayesianrvfl

Adaptive Bayesian (NON)Linear regression. 

## Note to self

```bash
git push https://{TOKEN}@github.com/thierrymoudiki/bayesianrvfl.git
```
