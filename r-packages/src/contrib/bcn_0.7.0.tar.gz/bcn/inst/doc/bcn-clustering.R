## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(bcn)
library(randomForest)
library(pROC)

## -----------------------------------------------------------------------------
library(bcn)
library(randomForest)
library(pROC)

## -----------------------------------------------------------------------------
data("iris")

## -----------------------------------------------------------------------------
head(iris)

dim(iris)

set.seed(1234)
train_idx <- sample(nrow(iris), 0.8 * nrow(iris))
X_train <- as.matrix(iris[train_idx, -ncol(iris)])
X_test <- as.matrix(iris[-train_idx, -ncol(iris)])
y_train <- iris$Species[train_idx]
y_test <- iris$Species[-train_idx]

## ----fit_iris-----------------------------------------------------------------
ptm <- proc.time()
fit_obj <- bcn::bcn(x = X_train, y = y_train, B = 10L, nu = 0.335855,
                    lam = 10**0.7837525, r = 1 - 10**(-5.470031), tol = 10**-7,
                    n_clusters = 3L,
                    activation = "tanh", type_optim = "nlminb", show_progress = FALSE)
cat("Elapsed: ", (proc.time() - ptm)[3])

## ----fig.width=7.2------------------------------------------------------------
plot(fit_obj$errors_norm, type='l')

## -----------------------------------------------------------------------------
preds <- predict(fit_obj, newx = X_test)

# accuracy
mean(preds == y_test)

# confusion matrix
table(y_test, preds)

## -----------------------------------------------------------------------------
rf <- randomForest::randomForest(x = X_train, y = y_train)
mean(predict(rf, newdata=as.matrix(X_test)) == y_test)

## -----------------------------------------------------------------------------
print(head(predict(fit_obj, newx = X_test, type='probs')))
print(head(predict(rf, newdata=as.matrix(X_test), type='prob')))

## -----------------------------------------------------------------------------
data(wine)

## -----------------------------------------------------------------------------
head(wine)

dim(wine)

set.seed(1234)
train_idx <- sample(nrow(wine), 0.8 * nrow(wine))
X_train <- as.matrix(wine[train_idx, -ncol(wine)])
X_test <- as.matrix(wine[-train_idx, -ncol(wine)])
y_train <- as.factor(wine$target[train_idx])
y_test <- as.factor(wine$target[-train_idx])

## ----fit_wine-----------------------------------------------------------------
ptm <- proc.time()
fit_obj <- bcn::bcn(x = X_train, y = y_train, B = 6L, nu = 0.8715725,
                    lam = 10**0.2143678, r = 1 - 10**(-6.1072786),
                    tol = 10**-4.9605713, 
                    n_clusters = 3L,
                    show_progress = FALSE)
cat("Elapsed: ", (proc.time() - ptm)[3])

## ----fig.width=7.2------------------------------------------------------------
plot(fit_obj$errors_norm, type='l')

## -----------------------------------------------------------------------------
preds <- predict(fit_obj, newx = X_test)

# accuracy
mean(preds == y_test)

# confusion matrix
table(y_test, preds)

## -----------------------------------------------------------------------------
rf <- randomForest::randomForest(x = X_train, y = y_train)
mean(predict(rf, newdata=as.matrix(X_test)) == y_test)

## -----------------------------------------------------------------------------
print(head(predict(fit_obj, newx = X_test, type='probs')))
print(head(predict(rf, newdata=as.matrix(X_test), type='prob')))

## -----------------------------------------------------------------------------
data("penguins")

## -----------------------------------------------------------------------------
penguins_ <- as.data.frame(penguins)

replacement <- median(penguins$bill_length_mm, na.rm = TRUE)
penguins_$bill_length_mm[is.na(penguins$bill_length_mm)] <- replacement

replacement <- median(penguins$bill_depth_mm, na.rm = TRUE)
penguins_$bill_depth_mm[is.na(penguins$bill_depth_mm)] <- replacement

replacement <- median(penguins$flipper_length_mm, na.rm = TRUE)
penguins_$flipper_length_mm[is.na(penguins$flipper_length_mm)] <- replacement

replacement <- median(penguins$body_mass_g, na.rm = TRUE)
penguins_$body_mass_g[is.na(penguins$body_mass_g)] <- replacement

# replacing NA's by the most frequent occurence
penguins_$sex[is.na(penguins$sex)] <- "male" # most frequent

print(summary(penguins_))
print(sum(is.na(penguins_)))

# one-hot encoding for covariates
penguins_mat <- model.matrix(species ~., data=penguins_)[,-1]
penguins_mat <- cbind(penguins_$species, penguins_mat)
penguins_mat <- as.data.frame(penguins_mat)
colnames(penguins_mat)[1] <- "species"

print(head(penguins_mat))
print(tail(penguins_mat))

y <- as.integer(penguins_mat$species)
X <- as.matrix(penguins_mat[,2:ncol(penguins_mat)])

n <- nrow(X)
p <- ncol(X)

set.seed(1234)
index_train <- sample(1:n, size=floor(0.8*n))
X_train <- X[index_train, ]
y_train <- factor(y[index_train])
X_test <- X[-index_train, ]
y_test <- factor(y[-index_train])

## ----fit_penguins-------------------------------------------------------------
ptm <- proc.time()
fit_obj <- bcn::bcn(x = X_train, y = y_train, B = 23, nu = 0.470043,
                    lam = 10**-0.05766029, r = 1 - 10**(-7.905866), tol = 10**-7, 
                    n_clusters = 3L,
                    show_progress = FALSE)
cat("Elapsed: ", (proc.time() - ptm)[3])

## ----fig.width=7.2------------------------------------------------------------
plot(fit_obj$errors_norm, type='l')

## -----------------------------------------------------------------------------
preds <- predict(fit_obj, newx = X_test)

# accuracy
mean(preds == y_test)

# confusion matrix
table(y_test, preds)

## -----------------------------------------------------------------------------
rf <- randomForest::randomForest(x = X_train, y = y_train)
mean(predict(rf, newdata=as.matrix(X_test)) == y_test)

## -----------------------------------------------------------------------------
print(head(predict(fit_obj, newx = X_test, type='probs')))
print(head(predict(rf, newdata=as.matrix(X_test), type='prob')))

