## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----include=FALSE------------------------------------------------------------
library(ahead)

## -----------------------------------------------------------------------------
data(EuStockMarkets)

EuStocks <- ts(EuStockMarkets[1:100, ], 
               start = start(EuStockMarkets),
               frequency = frequency(EuStockMarkets))

EuStocksLogReturns <- ahead::getreturns(EuStocks, type = "log")

print(head(EuStocksLogReturns))

## -----------------------------------------------------------------------------
ym <- c(0.03013425, 0.03026776, 0.03040053, 0.03053258, 0.03066390, 0.03079450, 0.03092437)

freq <- frequency(EuStocksLogReturns)
(start_preds <- tsp(EuStocksLogReturns)[2] + 1 / freq)
(ym <- stats::ts(ym,
                 start = start_preds,
                 frequency = frequency(EuStocksLogReturns)))

## ----echo=TRUE, eval=FALSE----------------------------------------------------
# obj <- ahead::ridge2f(EuStocksLogReturns, h = 7L,
#                       type_pi = 'bootstrap',
#                       B = 10L, ym = ym)

## ----echo=TRUE, eval=FALSE----------------------------------------------------
# rowMeans(obj$neutralized_sims$CAC)

## ----echo=TRUE, eval=FALSE----------------------------------------------------
# print(ym)

## ----echo=TRUE, eval=FALSE----------------------------------------------------
# rowMeans(obj$neutralized_sims$DAX)

## ----echo=TRUE, eval=FALSE----------------------------------------------------
# print(ym)

## ----echo=TRUE, fig.width=7.2, eval=FALSE-------------------------------------
# 
# #par(mfrow = c(2, 2))
# 
# matplot(EuStocksLogReturns, type = 'l',
#      main = "Historical log-Returns", xlab = "time")
# 
# plot(ym, main = "fake spot curve",
#      xlab = "time to maturity",
#      ylab = "yield",
#      ylim = c(0.02, 0.04))
# 
# matplot(obj$neutralized_sims$DAX, type = 'l',
#      main = "simulations of \n predicted DAX log-returns ('risk-neutral')",
#      ylim = c(0.02, 0.04),
#      ylab = "log-returns")
# 
# ci <- apply(obj$neutralized_sims$DAX, 1, function(x) t.test(x)$conf.int)
# plot(rowMeans(obj$neutralized_sims$DAX), type = 'l', main = "average predicted \n DAX log-returns ('risk-neutral')", col = "blue",
#      ylim = c(0.02, 0.04),
#      ylab = "log-returns")
# lines(ci[1, ], col = "red")
# lines(ci[2, ], col = "red")

