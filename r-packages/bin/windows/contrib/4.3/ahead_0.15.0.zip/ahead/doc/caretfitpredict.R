## -----------------------------------------------------------------------------
library(ahead)
library(forecast)

## -----------------------------------------------------------------------------
myfitfunc <- function(x, y) ahead::fit_func(x, y, method = "glmnet")

## ----fig.width=7.5------------------------------------------------------------
(obj1 <- ahead::dynrmf(USAccDeaths, h=20L, level=99))
(obj2 <- ahead::dynrmf(USAccDeaths, fit_func = myfitfunc, predict_func = ahead::predict_func, h=20L, level=99))

## ----fig.width=7.5------------------------------------------------------------
plot(obj1)

## ----fig.width=7.5------------------------------------------------------------
plot(obj2)

