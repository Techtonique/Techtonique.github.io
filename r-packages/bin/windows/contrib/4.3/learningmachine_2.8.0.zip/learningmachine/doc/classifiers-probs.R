## -----------------------------------------------------------------------------
rm(list=ls())

## ----message=FALSE, warning=FALSE---------------------------------------------
library(ggplot2)
library(learningmachine)
library(caret)
library(palmerpenguins)
library(mlbench)
library(skimr)
library(reshape2)
library(pROC)

## -----------------------------------------------------------------------------
set.seed(43)
X <- as.matrix(iris[, 1:4])
# y <- factor(as.numeric(iris$Species))
y <- iris$Species

index_train <- base::sample.int(n = nrow(X),
                                 size = floor(0.8*nrow(X)),
                                 replace = FALSE)
X_train <- X[index_train, ]
y_train <- y[index_train]
X_test <- X[-index_train, ]
y_test <- y[-index_train]
dim(X_train)
dim(X_test)

obj <- learningmachine::Classifier$new(method = "ranger", 
                                       pi_method="kdesplitconformal", 
                                       type_prediction_set="score")
obj$get_type()
obj$get_name()
obj$set_B(10)
obj$set_level(95)

t0 <- proc.time()[3]
obj$fit(X_train, y_train)
cat("Elapsed: ", proc.time()[3] - t0, "s \n")

probs <- obj$predict_proba(X_test)

## ----fig.width=8, fig.height=4, eval=TRUE-------------------------------------
df <- reshape2::melt(probs$sims$setosa[1:3, ])
df$Var2 <- NULL 
colnames(df) <- c("individual", "prob_setosa")
df$individual <- as.factor(df$individual)
ggplot2::ggplot(df, aes(x=individual, y=prob_setosa)) + geom_boxplot() + coord_flip()

## ----fig.width=8, fig.height=4, eval=TRUE-------------------------------------
ggplot2::ggplot(df, aes(x=prob_setosa, fill=individual)) + geom_density(alpha=.3)

## -----------------------------------------------------------------------------
print(head(X_test))
obj$summary(X_test, y=y_test, 
            class_name = "setosa",
            show_progress=FALSE)

## -----------------------------------------------------------------------------
print(head(X_test))
obj$summary(X_test, y=y_test, 
            class_name = "setosa",
            show_progress=FALSE, type_ci="conformal")

## -----------------------------------------------------------------------------
obj <- learningmachine::Classifier$new(method = "ranger", 
                                       type_prediction_set="score")
obj$set_level(95)
obj$set_pi_method("bootsplitconformal")
t0 <- proc.time()[3]
obj$fit(X_train, y_train)
cat("Elapsed: ", proc.time()[3] - t0, "s \n")

probs <- obj$predict_proba(X_test)

## ----fig.width=8, fig.height=4, eval=TRUE-------------------------------------
df <- reshape2::melt(probs$sims$setosa[1:3, ])
df$Var2 <- NULL 
colnames(df) <- c("individual", "prob_setosa")
df$individual <- as.factor(df$individual)
ggplot2::ggplot(df, aes(x=individual, y=prob_setosa)) + geom_boxplot() + coord_flip()

## ----fig.width=8, fig.height=4, eval=TRUE-------------------------------------
ggplot2::ggplot(df, aes(x=prob_setosa, fill=individual)) + geom_density(alpha=.3)

## -----------------------------------------------------------------------------
obj$summary(X_test, y=y_test, 
            class_name = "setosa",
            show_progress=FALSE)

## -----------------------------------------------------------------------------
obj$summary(X_test, y=y_test, 
            class_index = 2,
            show_progress=FALSE, type_ci="conformal")

## -----------------------------------------------------------------------------
obj <- learningmachine::Classifier$new(method = "extratrees", 
        pi_method = "bootsplitconformal", type_prediction_set="score")
obj$set_level(95)
t0 <- proc.time()[3]
obj$fit(X_train, y_train)
cat("Elapsed: ", proc.time()[3] - t0, "s \n")

## -----------------------------------------------------------------------------
probs <- obj$predict_proba(X_test)

## ----fig.width=8, fig.height=4, eval=TRUE-------------------------------------
df <- reshape2::melt(probs$sims$virginica[1:3, ])
df$Var2 <- NULL 
colnames(df) <- c("individual", "prob_virginica")
df$individual <- as.factor(df$individual)
ggplot2::ggplot(df, aes(x=individual, y=prob_virginica)) + geom_boxplot() + coord_flip()

## ----fig.width=8, fig.height=4, eval=TRUE-------------------------------------
ggplot2::ggplot(df, aes(x=prob_virginica, fill=individual)) + geom_density(alpha=.3)

## -----------------------------------------------------------------------------
obj$summary(X_test, y=y_test, 
            class_name = "virginica",
            show_progress=FALSE)

## -----------------------------------------------------------------------------
obj$summary(X_test, y=y_test, 
            class_name = "setosa",
            show_progress=FALSE, type_ci="conformal")

## -----------------------------------------------------------------------------
library(palmerpenguins)
data(penguins)

## -----------------------------------------------------------------------------
penguins_ <- as.data.frame(palmerpenguins::penguins)

replacement <- median(penguins$bill_length_mm, na.rm = TRUE)
penguins_$bill_length_mm[is.na(penguins$bill_length_mm)] <- replacement

replacement <- median(penguins$bill_depth_mm, na.rm = TRUE)
penguins_$bill_depth_mm[is.na(penguins$bill_depth_mm)] <- replacement

replacement <- median(penguins$flipper_length_mm, na.rm = TRUE)
penguins_$flipper_length_mm[is.na(penguins$flipper_length_mm)] <- replacement

replacement <- median(penguins$body_mass_g, na.rm = TRUE)
penguins_$body_mass_g[is.na(penguins$body_mass_g)] <- replacement

# replacing NA's by the most frequent occurence
penguins_$sex[is.na(penguins$sex)] <- "male" # most frequent

# one-hot encoding for covariates
penguins_mat <- model.matrix(species ~., data=penguins_)[,-1]
penguins_mat <- cbind.data.frame(penguins_$species, penguins_mat)
penguins_mat <- as.data.frame(penguins_mat)
colnames(penguins_mat)[1] <- "species"

y <- penguins_mat$species
X <- as.matrix(penguins_mat[,2:ncol(penguins_mat)])

n <- nrow(X)
p <- ncol(X)

set.seed(1234)
index_train <- sample(1:n, size=floor(0.8*n))
X_train <- X[index_train, ]
y_train <- factor(y[index_train])
X_test <- X[-index_train, ][1:5, ]
y_test <- factor(y[-index_train][1:5])

## -----------------------------------------------------------------------------
obj <- learningmachine::Classifier$new(method = "extratrees", 
                                       type_prediction_set="score")
obj$set_pi_method("bootsplitconformal")
obj$set_level(95)
obj$set_B(10L)
t0 <- proc.time()[3]
obj$fit(X_train, y_train)
cat("Elapsed: ", proc.time()[3] - t0, "s \n")

## ----eval=TRUE----------------------------------------------------------------
probs <- obj$predict_proba(X_test)

## ----fig.width=8, fig.height=4, eval=TRUE-------------------------------------
df <- reshape2::melt(probs$sims[[1]][1:3, ])
df$Var2 <- NULL 
colnames(df) <- c("individual", "prob_Adelie")
df$individual <- as.factor(df$individual)
ggplot2::ggplot(df, aes(x=individual, y=prob_Adelie)) + geom_boxplot() + coord_flip()

## ----fig.width=8, fig.height=4, eval=TRUE-------------------------------------
ggplot2::ggplot(df, aes(x=prob_Adelie, fill=individual)) + geom_density(alpha=.3)

## -----------------------------------------------------------------------------
obj$summary(X_test, y=y_test, 
            class_name = "Adelie",
            show_progress=FALSE)

## -----------------------------------------------------------------------------
obj <- learningmachine::Classifier$new(method = "rvfl", 
                                type_prediction_set="score")
obj$set_pi_method("bootsplitconformal")
obj$set_level(95)
obj$set_B(10L)
t0 <- proc.time()[3]
obj$fit(X_train, y_train)
cat("Elapsed: ", proc.time()[3] - t0, "s \n")

## ----eval=TRUE----------------------------------------------------------------
probs <- obj$predict_proba(X_test)

## ----fig.width=8, fig.height=4, eval=TRUE-------------------------------------
df <- reshape2::melt(probs$sims[[1]][1:3, ])
df$Var2 <- NULL 
colnames(df) <- c("individual", "prob_Adelie")
df$individual <- as.factor(df$individual)
ggplot2::ggplot(df, aes(x=individual, y=prob_Adelie)) + geom_boxplot() + coord_flip()

## ----fig.width=8, fig.height=4, eval=TRUE-------------------------------------
ggplot2::ggplot(df, aes(x=prob_Adelie, fill=individual)) + geom_density(alpha=.3)

## -----------------------------------------------------------------------------
obj$summary(X_test, y=y_test, 
            class_name = "Adelie",
            show_progress=FALSE)

